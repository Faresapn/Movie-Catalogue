package com.example.submisi5.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.submisi5.R;
import com.example.submisi5.adapter.Adapter;
import com.example.submisi5.model.Items.Items;
import com.example.submisi5.model.movie.MovieVM;
import com.example.submisi5.model.tv.ShowVM;

import java.util.ArrayList;

public class search_movietv extends AppCompatActivity implements Adapter.OnItemClickListener {
    public static final String EXTRA_SEARCH="extra_detail";
    Adapter adapter;
    MovieVM movieVM;
    ShowVM showVM;
    ProgressBar progressBar;
    RecyclerView recyclerView;
    Items items;
    String query,type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_movietv);
        toolbar();
        Detail();
        searchmovietv(query);
    }
    void toolbar(){
        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_backspace_black_24dp);
        toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));

        toolbar.setNavigationOnClickListener(view -> onBackPressed());
    }
    void searchmovietv(String title){
        progressBar = findViewById(R.id.search);
        progressBar.setVisibility(View.VISIBLE);

        adapter = new Adapter(search_movietv.this);
        adapter.setOnItemClickListener(search_movietv.this);
        adapter.notifyDataSetChanged();
        if (type.equals("MOVIE")){
            movieVM = ViewModelProviders.of(search_movietv.this).get(MovieVM.class);
            movieVM.getShow().observe(search_movietv.this,getMovieTvItems);
            movieVM.searchmovie(title);
        }else if (type.equals("TV")){
            showVM = ViewModelProviders.of(search_movietv.this).get(ShowVM.class);
            showVM.getShow().observe(search_movietv.this,getTvItems);
            showVM.searchtv(title);
        }


        recyclerView = findViewById(R.id.rv_search);
        recyclerView.setLayoutManager(new LinearLayoutManager(search_movietv.this,RecyclerView.VERTICAL,false));
        recyclerView.setAdapter(adapter);
    }
    void Detail(){
        items = new Items();
        items = getIntent().getParcelableExtra(EXTRA_SEARCH);
        query = items.getTitle_film();
        type = items.getType();
    }
    private Observer<? super ArrayList<Items>> getMovieTvItems = (Observer<ArrayList<Items>>) items -> {
        if (items!=null){
            adapter.setmItems(items);
            progressBar.setVisibility(View.GONE);
        }
    };

    private Observer<? super ArrayList<Items>> getTvItems = (Observer<ArrayList<Items>>) items -> {
        if (items!=null){
            adapter.setmItems(items);
            progressBar.setVisibility(View.GONE);
        }
    };
    @Override
    public void onItemClick(int position) {

    }
}
